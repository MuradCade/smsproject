<form action="api.php" method="post">
<label>Phone Number</label>
<input type="text" name='number'/>

<label>Message</label>
<input type="text" name='msg'/>

<button  name="submit">Submit</button>

</form>
